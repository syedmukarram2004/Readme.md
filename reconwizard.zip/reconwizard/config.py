"""
Configuration settings for ReconWizard
"""

# Default settings
DEFAULT_TIMEOUT = 10
DEFAULT_THREADS = 10
DEFAULT_PORT_RANGE = "1-1000"

# API Settings
USER_AGENT = "ReconWizard/1.0 (Security Research Tool)"

# Output settings
DEFAULT_OUTPUT_DIR = "reports"
DEFAULT_OUTPUT_FORMAT = "both"  # txt, html, json, both

# Port scanning settings
COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 993, 995, 1723, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 9200, 27017]

# Logging settings
LOG_LEVELS = {
    0: "ERROR",
    1: "INFO", 
    2: "DEBUG",
    3: "TRACE"
}