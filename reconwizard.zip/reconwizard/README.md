# ReconWizard - Modular Reconnaissance Tool

![ReconWizard Logo](https://img.shields.io/badge/ReconWizard-v1.0-blue)
![Python Version](https://img.shields.io/badge/python-3.7+-green)
![License](https://img.shields.io/badge/license-MIT-blue)

## Overview

ReconWizard is a comprehensive, modular reconnaissance tool designed for penetration testing and security research. It automates the initial information gathering phase by performing both passive and active reconnaissance techniques to collect detailed information about target domains.

## Features

### 🔍 Passive Reconnaissance
- **WHOIS Lookup**: Domain registration information, registrar details, creation/expiration dates
- **DNS Enumeration**: Comprehensive DNS record collection (A, AAAA, MX, TXT, NS, CNAME, SOA, SRV)
- **Subdomain Discovery**: Multi-source subdomain enumeration using Certificate Transparency, AlienVault OTX, and other APIs
- **Certificate Analysis**: SSL/TLS certificate inspection and Subject Alternative Name extraction

### 🎯 Active Reconnaissance
- **Port Scanning**: TCP/UDP port scanning with Nmap integration and socket-based fallback
- **Banner Grabbing**: Service identification and version detection
- **Technology Detection**: Web framework, CMS, and technology stack identification
- **HTTP Analysis**: Header analysis, cookie inspection, and response fingerprinting

### 📊 Reporting & Output
- **Multiple Formats**: Generate reports in TXT, HTML, and JSON formats
- **Detailed Analytics**: Comprehensive analysis with timestamps and IP resolution
- **Modular Execution**: Run individual modules or comprehensive scans
- **Verbose Logging**: Configurable logging levels for debugging and monitoring

## Installation

### Prerequisites
- Python 3.7 or higher
- pip package manager
- nmap (optional, for advanced port scanning)

### Quick Setup
```bash
# Clone or download ReconWizard
git clone <repository-url>
cd reconwizard

# Install dependencies
pip install requests dnspython python-whois

# Run ReconWizard
python3 reconwizard.py --help
```

### Manual Installation
```bash
pip install requests dnspython python-whois
```

### Optional Dependencies
```bash
# For advanced port scanning capabilities
sudo apt-get install nmap  # Linux
brew install nmap          # macOS
```

## Usage

### Basic Usage
```bash
# Display help and available options
python3 reconwizard.py --help

# Run comprehensive reconnaissance
python3 reconwizard.py example.com --all

# Run specific modules
python3 reconwizard.py example.com --whois --dns
python3 reconwizard.py example.com --subdomains --tech
python3 reconwizard.py example.com --ports --banner
```

### Advanced Usage
```bash
# Custom port range scanning
python3 reconwizard.py example.com --ports --ports-range 1-1000

# Specific output format
python3 reconwizard.py example.com --all --output html
python3 reconwizard.py example.com --dns --output txt

# Custom output directory
python3 reconwizard.py example.com --all --output-dir /custom/path

# Verbose logging
python3 reconwizard.py example.com --whois --dns -v
python3 reconwizard.py example.com --all -vv  # Very verbose
```

### Module-Specific Examples
```bash
# WHOIS and DNS only
python3 reconwizard.py target.com --whois --dns

# Subdomain enumeration with technology detection
python3 reconwizard.py target.com --subdomains --tech

# Port scanning with banner grabbing
python3 reconwizard.py target.com --ports --banner --ports-range 1-65535

# Quick scan of common ports
python3 reconwizard.py target.com --ports --ports-range 21,22,23,25,53,80,110,443,993,995
```

## Command Line Options

| Option | Description | Default |
|--------|-------------|---------|
| `target` | Target domain to scan | Required |
| `--whois` | Perform WHOIS lookup | Disabled |
| `--dns` | Perform DNS enumeration | Disabled |
| `--subdomains` | Perform subdomain enumeration | Disabled |
| `--ports` | Perform port scanning | Disabled |
| `--banner` | Perform banner grabbing | Disabled |
| `--tech` | Perform technology detection | Disabled |
| `--all` | Run all reconnaissance modules | Disabled |
| `--ports-range` | Port range for scanning | 1-1000 |
| `--output` | Output format (txt, html, both) | both |
| `--output-dir` | Output directory for reports | reports |
| `-v, --verbose` | Increase verbosity level | Normal |
| `-q, --quiet` | Suppress output except errors | Disabled |

## Output Formats

ReconWizard generates reports in multiple formats:

### Text Report (.txt)
- Clean, structured text format
- Easy to read and parse
- Suitable for command-line review

### HTML Report (.html)
- Professional web-based format
- Interactive and visually appealing
- Includes statistics and organized sections

### JSON Data (.json)
- Machine-readable format
- Perfect for automation and integration
- Contains all collected data with timestamps

## Modules Overview

### 🔍 WHOIS Lookup (`--whois`)
- Domain registration information
- Registrar details and contact info
- Creation, expiration, and update dates
- Nameserver information
- IP resolution

### 🌐 DNS Enumeration (`--dns`)
- A, AAAA, MX, TXT, NS, CNAME, SOA, SRV records
- Reverse DNS lookup (PTR records)
- Security records (SPF, DMARC, DKIM, CAA)
- DNS bruteforce for common subdomains
- Wildcard detection

### 🔎 Subdomain Enumeration (`--subdomains`)
- Certificate Transparency logs (crt.sh)
- AlienVault OTX database
- Hackertarget API
- ThreatCrowd API
- DNS Dumpster scraping
- Google dorking
- SSL certificate analysis

### 🚪 Port Scanning (`--ports`)
- TCP port scanning with Nmap integration
- Socket-based fallback scanning
- UDP port scanning support
- Service detection and version identification
- Stealth scanning capabilities
- Custom port ranges

### 📋 Banner Grabbing (`--banner`)
- Service banner collection
- SSL/TLS certificate analysis
- HTTP header extraction
- Service version identification
- Vulnerability hints from banners

### 🔧 Technology Detection (`--tech`)
- Web server identification
- Framework and CMS detection
- JavaScript library identification
- CDN and security header analysis
- Cookie-based technology detection
- Common path analysis

## Sample Output

### Example Command
```bash
python3 reconwizard.py example.com --whois --dns --ports-range 80,443 --output both
```

### Generated Files
- `reports/example.com_20250609_161226.txt` - Text report
- `reports/example.com_20250609_161226.html` - HTML report  
- `reports/example.com_20250609_161226.json` - JSON data

See `sample_output/` directory for example reports.

## Security Considerations

⚠️ **Important Security Notes:**

1. **Legal Compliance**: Only use ReconWizard against domains you own or have explicit permission to test
2. **Rate Limiting**: Tool includes built-in delays to respect external APIs
3. **Passive First**: Start with passive reconnaissance before active scanning
4. **Network Impact**: Port scanning can be detected - use responsibly
5. **Data Sensitivity**: Generated reports may contain sensitive information

## Troubleshooting

### Common Issues

**DNS Resolution Errors**
```bash
# Check your DNS configuration
nslookup example.com
# Try different DNS servers if needed
```

**Permission Errors for Port Scanning**
```bash
# Some advanced scans require elevated privileges
sudo python3 reconwizard.py target.com --ports
```

**Module Import Errors**
```bash
# Ensure all dependencies are installed
pip install -r requirements.txt
```

**Timeout Issues**
```bash
# Reduce scan scope for slow networks
python3 reconwizard.py target.com --ports --ports-range 80,443
```

## Development

### Project Structure
```
reconwizard/
├── modules/                 # Reconnaissance modules
│   ├── __init__.py         # Module package initialization
│   ├── whois_lookup.py     # WHOIS functionality
│   ├── dns_enum.py         # DNS enumeration
│   ├── subdomain_enum.py   # Subdomain discovery
│   ├── port_scan.py        # Port scanning
│   ├── banner_grab.py      # Banner grabbing
│   └── tech_detect.py      # Technology detection
├── reports/                # Generated reports directory
├── sample_output/          # Example output files
├── reconwizard.py         # Main application
├── utils.py               # Utility functions
└── README.md              # Documentation
```

### Adding Custom Modules
1. Create new module in `modules/` directory
2. Implement required interface methods
3. Add module import to `__init__.py`
4. Update main application logic

## License

MIT License - See LICENSE file for details.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Implement your changes
4. Add tests and documentation
5. Submit a pull request

## Disclaimer

ReconWizard is developed for educational and authorized security testing purposes only. Users are responsible for ensuring compliance with applicable laws and regulations. The developers assume no liability for misuse of this tool.

---

**Author**: ReconWizard Development Team  
**Version**: 1.0.0  
**Last Updated**: June 2025
