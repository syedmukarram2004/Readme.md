from setuptools import setup, find_packages

setup(
    name="reconwizard",
    version="1.0.0",
    author="ReconWizard Development Team",
    description="A modular reconnaissance tool for penetration testing",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1",
        "dnspython>=2.1.0", 
        "python-whois>=0.7.3"
    ],
    python_requires=">=3.7",
    entry_points={
        'console_scripts': [
            'reconwizard=reconwizard:main',
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
    ],
)