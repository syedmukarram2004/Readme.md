"""
Port Scanning Module for ReconWizard

Performs comprehensive port scanning using both Nmap (if available) and native Python sockets.
Includes service detection, OS fingerprinting, and common port scanning techniques.
"""

import socket
import subprocess
import threading
import time
import json
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
import tempfile
import os


class PortScanner:
    """Port scanning functionality"""
    
    def __init__(self, logger):
        """
        Initialize port scanner module
        
        Args:
            logger: Logger instance for output
        """
        self.logger = logger
        self.timeout = 3
        self.nmap_available = self._check_nmap_availability()
        
        # Common ports and their services
        self.common_ports = {
            21: 'ftp', 22: 'ssh', 23: 'telnet', 25: 'smtp', 53: 'dns',
            80: 'http', 110: 'pop3', 111: 'rpcbind', 135: 'msrpc', 139: 'netbios-ssn',
            143: 'imap', 443: 'https', 993: 'imaps', 995: 'pop3s', 1723: 'pptp',
            3306: 'mysql', 3389: 'rdp', 5432: 'postgresql', 5900: 'vnc', 6379: 'redis',
            27017: 'mongodb', 8080: 'http-proxy', 8443: 'https-alt', 9200: 'elasticsearch'
        }
    
    def scan(self, target, ports=None, scan_type='tcp'):
        """
        Perform port scan on target
        
        Args:
            target (str): Target host/domain to scan
            ports (list): List of ports to scan, defaults to common ports
            scan_type (str): Type of scan ('tcp', 'udp', 'syn')
        
        Returns:
            list: List of port scan results
        """
        self.logger.info(f"Starting port scan for {target}")
        
        if ports is None:
            ports = list(self.common_ports.keys())
        
        # Resolve target to IP if it's a domain
        target_ip = self._resolve_target(target)
        if not target_ip:
            self.logger.error(f"Could not resolve target: {target}")
            return []
        
        # Use Nmap if available, otherwise use socket scanning
        if self.nmap_available and len(ports) > 50:
            self.logger.info("Using Nmap for port scanning")
            results = self._nmap_scan(target_ip, ports, scan_type)
        else:
            self.logger.info("Using socket-based port scanning")
            results = self._socket_scan(target_ip, ports)
        
        self.logger.info(f"Port scan completed. Scanned {len(ports)} ports")
        return results
    
    def _check_nmap_availability(self):
        """
        Check if Nmap is available on the system
        
        Returns:
            bool: True if Nmap is available, False otherwise
        """
        try:
            result = subprocess.run(['nmap', '--version'], 
                                 capture_output=True, 
                                 text=True, 
                                 timeout=10)
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False
    
    def _resolve_target(self, target):
        """
        Resolve target domain to IP address
        
        Args:
            target (str): Target domain or IP
        
        Returns:
            str: IP address or None if resolution fails
        """
        try:
            return socket.gethostbyname(target)
        except socket.gaierror:
            self.logger.error(f"Could not resolve {target}")
            return None
    
    def _socket_scan(self, target_ip, ports):
        """
        Perform socket-based port scanning
        
        Args:
            target_ip (str): Target IP address
            ports (list): List of ports to scan
        
        Returns:
            list: List of scan results
        """
        results = []
        
        def scan_port(port):
            """Scan individual port"""
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(self.timeout)
                
                start_time = time.time()
                result = sock.connect_ex((target_ip, port))
                end_time = time.time()
                
                response_time = round((end_time - start_time) * 1000, 2)
                
                if result == 0:
                    service = self.common_ports.get(port, 'unknown')
                    
                    return {
                        'port': port,
                        'protocol': 'tcp',
                        'status': 'open',
                        'service': service,
                        'response_time': response_time
                    }
                else:
                    return {
                        'port': port,
                        'protocol': 'tcp',
                        'status': 'closed',
                        'response_time': response_time
                    }
                
            except socket.timeout:
                return {
                    'port': port,
                    'protocol': 'tcp',
                    'status': 'filtered',
                    'response_time': self.timeout * 1000
                }
            except Exception as e:
                self.logger.debug(f"Error scanning port {port}: {str(e)}")
                return {
                    'port': port,
                    'protocol': 'tcp',
                    'status': 'error',
                    'error': str(e)
                }
            finally:
                try:
                    sock.close()
                except:
                    pass
        
        # Use threading for concurrent port scanning
        max_threads = min(100, len(ports))
        
        with ThreadPoolExecutor(max_workers=max_threads) as executor:
            future_to_port = {executor.submit(scan_port, port): port for port in ports}
            
            for future in as_completed(future_to_port):
                port = future_to_port[future]
                try:
                    result = future.result()
                    if result:
                        results.append(result)
                        if result['status'] == 'open':
                            self.logger.debug(f"Port {port} is open ({result['service']})")
                except Exception as e:
                    self.logger.debug(f"Error processing port {port}: {str(e)}")
        
        return results
    
    def _nmap_scan(self, target_ip, ports, scan_type='tcp'):
        """
        Perform Nmap-based port scanning
        
        Args:
            target_ip (str): Target IP address
            ports (list): List of ports to scan
            scan_type (str): Type of scan
        
        Returns:
            list: List of scan results
        """
        results = []
        
        try:
            # Prepare port range
            port_range = self._format_port_range(ports)
            
            # Build Nmap command
            nmap_cmd = ['nmap', '-Pn', '-sV', '--version-intensity', '2']
            
            if scan_type == 'syn':
                nmap_cmd.append('-sS')
            elif scan_type == 'udp':
                nmap_cmd.append('-sU')
            else:
                nmap_cmd.append('-sT')
            
            nmap_cmd.extend(['-p', port_range, target_ip, '-oX', '-'])
            
            self.logger.debug(f"Running Nmap command: {' '.join(nmap_cmd)}")
            
            # Execute Nmap
            result = subprocess.run(nmap_cmd, 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=300)
            
            if result.returncode == 0:
                results = self._parse_nmap_xml(result.stdout)
            else:
                self.logger.error(f"Nmap scan failed: {result.stderr}")
                # Fallback to socket scanning
                results = self._socket_scan(target_ip, ports)
        
        except subprocess.TimeoutExpired:
            self.logger.warning("Nmap scan timed out, falling back to socket scanning")
            results = self._socket_scan(target_ip, ports)
        except Exception as e:
            self.logger.error(f"Nmap scan error: {str(e)}")
            results = self._socket_scan(target_ip, ports)
        
        return results
    
    def _format_port_range(self, ports):
        """
        Format port list for Nmap
        
        Args:
            ports (list): List of ports
        
        Returns:
            str: Formatted port range string
        """
        if not ports:
            return "1-65535"
        
        # Sort ports and create ranges
        sorted_ports = sorted(ports)
        ranges = []
        start = sorted_ports[0]
        end = sorted_ports[0]
        
        for port in sorted_ports[1:]:
            if port == end + 1:
                end = port
            else:
                if start == end:
                    ranges.append(str(start))
                else:
                    ranges.append(f"{start}-{end}")
                start = end = port
        
        # Add the last range
        if start == end:
            ranges.append(str(start))
        else:
            ranges.append(f"{start}-{end}")
        
        return ','.join(ranges)
    
    def _parse_nmap_xml(self, xml_output):
        """
        Parse Nmap XML output
        
        Args:
            xml_output (str): Nmap XML output
        
        Returns:
            list: Parsed scan results
        """
        results = []
        
        try:
            root = ET.fromstring(xml_output)
            
            for host in root.findall('host'):
                for port in host.findall('.//port'):
                    port_id = int(port.get('portid'))
                    protocol = port.get('protocol')
                    
                    state = port.find('state')
                    port_state = state.get('state') if state is not None else 'unknown'
                    
                    service = port.find('service')
                    service_name = 'unknown'
                    service_version = ''
                    
                    if service is not None:
                        service_name = service.get('name', 'unknown')
                        product = service.get('product', '')
                        version = service.get('version', '')
                        if product and version:
                            service_version = f"{product} {version}"
                        elif product:
                            service_version = product
                    
                    result = {
                        'port': port_id,
                        'protocol': protocol,
                        'status': port_state,
                        'service': service_name
                    }
                    
                    if service_version:
                        result['version'] = service_version
                    
                    results.append(result)
        
        except ET.ParseError as e:
            self.logger.error(f"Failed to parse Nmap XML output: {str(e)}")
        
        return results
    
    def stealth_scan(self, target, ports=None):
        """
        Perform stealth SYN scan
        
        Args:
            target (str): Target host
            ports (list): Ports to scan
        
        Returns:
            list: Scan results
        """
        self.logger.info(f"Performing stealth scan on {target}")
        
        if self.nmap_available:
            target_ip = self._resolve_target(target)
            if target_ip:
                return self._nmap_scan(target_ip, ports or list(self.common_ports.keys()), 'syn')
        
        # Fallback to regular TCP scan
        self.logger.warning("Stealth scan not available, using regular TCP scan")
        return self.scan(target, ports)
    
    def udp_scan(self, target, ports=None):
        """
        Perform UDP port scan
        
        Args:
            target (str): Target host
            ports (list): Ports to scan
        
        Returns:
            list: Scan results
        """
        self.logger.info(f"Performing UDP scan on {target}")
        
        if ports is None:
            # Common UDP ports
            ports = [53, 67, 68, 69, 123, 135, 137, 138, 139, 161, 162, 445, 500, 514, 520, 1434, 1900, 4500, 5353]
        
        if self.nmap_available:
            target_ip = self._resolve_target(target)
            if target_ip:
                return self._nmap_scan(target_ip, ports, 'udp')
        
        # UDP scanning with sockets is less reliable
        self.logger.warning("UDP scan without Nmap may be inaccurate")
        return self._udp_socket_scan(target, ports)
    
    def _udp_socket_scan(self, target, ports):
        """
        Perform UDP scanning using sockets
        
        Args:
            target (str): Target host
            ports (list): Ports to scan
        
        Returns:
            list: Scan results
        """
        results = []
        target_ip = self._resolve_target(target)
        
        if not target_ip:
            return results
        
        def scan_udp_port(port):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(2)
                
                # Send empty UDP packet
                sock.sendto(b'', (target_ip, port))
                
                try:
                    # Try to receive response
                    data, addr = sock.recvfrom(1024)
                    return {
                        'port': port,
                        'protocol': 'udp',
                        'status': 'open',
                        'service': self.common_ports.get(port, 'unknown')
                    }
                except socket.timeout:
                    # No response - could be open or filtered
                    return {
                        'port': port,
                        'protocol': 'udp',
                        'status': 'open|filtered',
                        'service': self.common_ports.get(port, 'unknown')
                    }
            
            except Exception as e:
                return {
                    'port': port,
                    'protocol': 'udp',
                    'status': 'error',
                    'error': str(e)
                }
            finally:
                try:
                    sock.close()
                except:
                    pass
        
        with ThreadPoolExecutor(max_workers=20) as executor:
            future_to_port = {executor.submit(scan_udp_port, port): port for port in ports}
            
            for future in as_completed(future_to_port):
                result = future.result()
                if result:
                    results.append(result)
        
        return results
    
    def get_open_ports(self, scan_results):
        """
        Filter scan results to return only open ports
        
        Args:
            scan_results (list): Port scan results
        
        Returns:
            list: Open ports only
        """
        return [result for result in scan_results if result.get('status') == 'open']
    
    def port_knock(self, target, knock_sequence):
        """
        Perform port knocking sequence
        
        Args:
            target (str): Target host
            knock_sequence (list): Sequence of ports to knock
        
        Returns:
            bool: True if sequence completed successfully
        """
        self.logger.info(f"Performing port knock sequence on {target}: {knock_sequence}")
        
        target_ip = self._resolve_target(target)
        if not target_ip:
            return False
        
        try:
            for port in knock_sequence:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                try:
                    sock.connect((target_ip, port))
                except:
                    pass  # Connection failure is expected for port knocking
                finally:
                    sock.close()
                
                time.sleep(0.5)  # Small delay between knocks
            
            self.logger.info("Port knock sequence completed")
            return True
        
        except Exception as e:
            self.logger.error(f"Port knock sequence failed: {str(e)}")
            return False
