"""
Banner Grabbing Module for ReconWizard

Performs banner grabbing on open ports to identify services, versions, and 
gather additional information about running services.
"""

import socket
import ssl
import time
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import struct


class BannerGrabber:
    """Banner grabbing functionality"""
    
    def __init__(self, logger):
        """
        Initialize banner grabber module
        
        Args:
            logger: Logger instance for output
        """
        self.logger = logger
        self.timeout = 10
        
        # Service-specific probes and patterns
        self.service_probes = {
            21: {'probe': b'', 'name': 'FTP'},
            22: {'probe': b'', 'name': 'SSH'},
            23: {'probe': b'', 'name': 'Telnet'},
            25: {'probe': b'HELO reconwizard\r\n', 'name': 'SMTP'},
            53: {'probe': b'', 'name': 'DNS'},
            80: {'probe': b'HEAD / HTTP/1.1\r\nHost: target\r\n\r\n', 'name': 'HTTP'},
            110: {'probe': b'', 'name': 'POP3'},
            143: {'probe': b'', 'name': 'IMAP'},
            443: {'probe': b'HEAD / HTTP/1.1\r\nHost: target\r\n\r\n', 'name': 'HTTPS'},
            993: {'probe': b'', 'name': 'IMAPS'},
            995: {'probe': b'', 'name': 'POP3S'},
            3306: {'probe': b'', 'name': 'MySQL'},
            5432: {'probe': b'', 'name': 'PostgreSQL'},
            6379: {'probe': b'INFO\r\n', 'name': 'Redis'},
        }
    
    def grab_banners(self, target, open_ports):
        """
        Grab banners from open ports
        
        Args:
            target (str): Target host
            open_ports (list): List of open port dictionaries
        
        Returns:
            dict: Dictionary with port as key and banner as value
        """
        self.logger.info(f"Starting banner grabbing for {target}")
        
        banners = {}
        
        # Extract port numbers from port dictionaries
        ports_to_scan = []
        for port_info in open_ports:
            if isinstance(port_info, dict) and 'port' in port_info:
                ports_to_scan.append(port_info['port'])
            elif isinstance(port_info, int):
                ports_to_scan.append(port_info)
        
        # Grab banners concurrently
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_port = {
                executor.submit(self._grab_banner, target, port): port 
                for port in ports_to_scan
            }
            
            for future in as_completed(future_to_port):
                port = future_to_port[future]
                try:
                    banner = future.result()
                    if banner:
                        banners[port] = banner
                        self.logger.debug(f"Banner grabbed from port {port}")
                except Exception as e:
                    self.logger.debug(f"Banner grab failed for port {port}: {str(e)}")
        
        self.logger.info(f"Banner grabbing completed. Got {len(banners)} banners")
        return banners
    
    def _grab_banner(self, target, port):
        """
        Grab banner from a specific port
        
        Args:
            target (str): Target host
            port (int): Port number
        
        Returns:
            str: Banner text or None if failed
        """
        try:
            if port in [443, 993, 995]:  # SSL/TLS ports
                return self._grab_ssl_banner(target, port)
            else:
                return self._grab_tcp_banner(target, port)
        
        except Exception as e:
            self.logger.debug(f"Banner grab error for {target}:{port} - {str(e)}")
            return None
    
    def _grab_tcp_banner(self, target, port):
        """
        Grab banner from TCP port
        
        Args:
            target (str): Target host
            port (int): Port number
        
        Returns:
            str: Banner text
        """
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            
            # Connect to target
            sock.connect((target, port))
            
            # Send service-specific probe if available
            probe_info = self.service_probes.get(port, {'probe': b'', 'name': 'Unknown'})
            probe = probe_info['probe']
            
            if probe:
                # Replace placeholder with actual target
                if b'target' in probe:
                    probe = probe.replace(b'target', target.encode())
                sock.send(probe)
            
            # Read banner
            banner_data = b''
            start_time = time.time()
            
            while time.time() - start_time < self.timeout:
                try:
                    chunk = sock.recv(1024)
                    if not chunk:
                        break
                    banner_data += chunk
                    
                    # Stop if we have enough data or hit common terminators
                    if len(banner_data) > 4096 or b'\n\n' in banner_data or b'\r\n\r\n' in banner_data:
                        break
                        
                except socket.timeout:
                    break
            
            if banner_data:
                # Clean up banner
                banner_text = banner_data.decode('utf-8', errors='ignore').strip()
                return self._clean_banner(banner_text, port)
            
        except Exception as e:
            self.logger.debug(f"TCP banner grab failed for {target}:{port} - {str(e)}")
        
        finally:
            if sock:
                try:
                    sock.close()
                except:
                    pass
        
        return None
    
    def _grab_ssl_banner(self, target, port):
        """
        Grab banner from SSL/TLS port
        
        Args:
            target (str): Target host
            port (int): Port number
        
        Returns:
            str: Banner text including SSL certificate info
        """
        sock = None
        ssl_sock = None
        
        try:
            # Create SSL context
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            
            # Connect with SSL
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            sock.connect((target, port))
            
            ssl_sock = context.wrap_socket(sock, server_hostname=target)
            
            # Get certificate information
            cert = ssl_sock.getpeercert()
            ssl_info = []
            
            if cert:
                # Extract certificate details
                if 'subject' in cert:
                    subject = dict(x[0] for x in cert['subject'])
                    if 'commonName' in subject:
                        ssl_info.append(f"Common Name: {subject['commonName']}")
                    if 'organizationName' in subject:
                        ssl_info.append(f"Organization: {subject['organizationName']}")
                
                if 'issuer' in cert:
                    issuer = dict(x[0] for x in cert['issuer'])
                    if 'organizationName' in issuer:
                        ssl_info.append(f"Issuer: {issuer['organizationName']}")
                
                if 'version' in cert:
                    ssl_info.append(f"Certificate Version: {cert['version']}")
                
                if 'notAfter' in cert:
                    ssl_info.append(f"Expires: {cert['notAfter']}")
            
            # Get SSL/TLS version
            ssl_info.append(f"SSL/TLS Version: {ssl_sock.version()}")
            ssl_info.append(f"Cipher: {ssl_sock.cipher()}")
            
            # Try to get application banner for HTTPS
            if port == 443:
                try:
                    http_request = f"HEAD / HTTP/1.1\r\nHost: {target}\r\n\r\n"
                    ssl_sock.send(http_request.encode())
                    
                    response = b''
                    start_time = time.time()
                    
                    while time.time() - start_time < 5:
                        try:
                            chunk = ssl_sock.recv(1024)
                            if not chunk:
                                break
                            response += chunk
                            if b'\r\n\r\n' in response:
                                break
                        except socket.timeout:
                            break
                    
                    if response:
                        http_banner = response.decode('utf-8', errors='ignore').strip()
                        ssl_info.append("HTTP Response:")
                        ssl_info.append(http_banner)
                
                except Exception as e:
                    self.logger.debug(f"HTTP banner grab failed on SSL port: {str(e)}")
            
            return '\n'.join(ssl_info)
        
        except Exception as e:
            self.logger.debug(f"SSL banner grab failed for {target}:{port} - {str(e)}")
        
        finally:
            if ssl_sock:
                try:
                    ssl_sock.close()
                except:
                    pass
            if sock:
                try:
                    sock.close()
                except:
                    pass
        
        return None
    
    def _clean_banner(self, banner, port):
        """
        Clean and format banner text
        
        Args:
            banner (str): Raw banner text
            port (int): Port number for context
        
        Returns:
            str: Cleaned banner text
        """
        if not banner:
            return None
        
        # Remove excessive whitespace
        lines = [line.strip() for line in banner.split('\n') if line.strip()]
        cleaned_banner = '\n'.join(lines)
        
        # Limit banner length
        if len(cleaned_banner) > 2000:
            cleaned_banner = cleaned_banner[:2000] + "... [truncated]"
        
        return cleaned_banner
    
    def extract_service_info(self, banners):
        """
        Extract service information from banners
        
        Args:
            banners (dict): Dictionary of port->banner mappings
        
        Returns:
            dict: Extracted service information
        """
        service_info = {}
        
        for port, banner in banners.items():
            if not banner:
                continue
            
            info = {
                'port': port,
                'service': 'unknown',
                'version': '',
                'details': []
            }
            
            # Service identification patterns
            patterns = {
                'apache': r'Apache[/\s]*([\d.]+)',
                'nginx': r'nginx[/\s]*([\d.]+)',
                'iis': r'Microsoft-IIS[/\s]*([\d.]+)',
                'ssh': r'OpenSSH[_\s]*([\d.]+)',
                'ftp': r'FTP.*?Server\s*([\w\s.]+)',
                'mysql': r'MySQL.*?([\d.]+)',
                'postgresql': r'PostgreSQL.*?([\d.]+)',
                'redis': r'Redis.*?version[:\s]*([\d.]+)',
                'smtp': r'SMTP.*?([\w\s.]+)',
                'pop3': r'POP3.*?([\w\s.]+)',
                'imap': r'IMAP.*?([\w\s.]+)'
            }
            
            banner_lower = banner.lower()
            
            for service, pattern in patterns.items():
                match = re.search(pattern, banner, re.IGNORECASE)
                if match:
                    info['service'] = service
                    if match.groups():
                        info['version'] = match.group(1).strip()
                    break
            
            # Extract additional details
            if 'server:' in banner_lower:
                server_match = re.search(r'server:\s*([^\r\n]+)', banner, re.IGNORECASE)
                if server_match:
                    info['details'].append(f"Server: {server_match.group(1).strip()}")
            
            if 'powered by' in banner_lower:
                powered_match = re.search(r'powered[- ]by[:\s]*([^\r\n]+)', banner, re.IGNORECASE)
                if powered_match:
                    info['details'].append(f"Powered by: {powered_match.group(1).strip()}")
            
            service_info[port] = info
        
        return service_info
    
    def vulnerability_hints(self, banners):
        """
        Identify potential vulnerabilities from banners
        
        Args:
            banners (dict): Dictionary of port->banner mappings
        
        Returns:
            dict: Potential vulnerability information
        """
        vulns = {}
        
        # Known vulnerable version patterns
        vuln_patterns = {
            'apache': {
                r'Apache/2\.2\.[0-9]': 'Potentially vulnerable to CVE-2011-3192 (Range header DoS)',
                r'Apache/2\.4\.[0-6]': 'Potentially vulnerable to CVE-2014-0098'
            },
            'openssh': {
                r'OpenSSH_[1-6]\.[0-9]': 'Potentially vulnerable to various SSH exploits',
                r'OpenSSH_7\.[0-3]': 'Potentially vulnerable to CVE-2016-6210'
            },
            'mysql': {
                r'MySQL 5\.[0-5]': 'Potentially vulnerable to various MySQL exploits',
            },
            'iis': {
                r'Microsoft-IIS/[6-7]\.': 'Potentially vulnerable to various IIS exploits'
            }
        }
        
        for port, banner in banners.items():
            if not banner:
                continue
            
            port_vulns = []
            
            for service, patterns in vuln_patterns.items():
                for pattern, description in patterns.items():
                    if re.search(pattern, banner, re.IGNORECASE):
                        port_vulns.append(description)
            
            # Check for default/weak configurations
            if 'welcome' in banner.lower() and 'default' in banner.lower():
                port_vulns.append('Potentially using default configuration')
            
            if port_vulns:
                vulns[port] = port_vulns
        
        return vulns
    
    def grab_http_headers(self, target, port=80, ssl=False):
        """
        Grab HTTP headers specifically
        
        Args:
            target (str): Target host
            port (int): Port number
            ssl (bool): Use SSL/TLS
        
        Returns:
            dict: HTTP headers
        """
        headers = {}
        
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            sock.connect((target, port))
            
            if ssl:
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                sock = context.wrap_socket(sock, server_hostname=target)
            
            # Send HTTP request
            request = f"HEAD / HTTP/1.1\r\nHost: {target}\r\nUser-Agent: ReconWizard/1.0\r\n\r\n"
            sock.send(request.encode())
            
            # Read response
            response = b''
            while b'\r\n\r\n' not in response:
                chunk = sock.recv(1024)
                if not chunk:
                    break
                response += chunk
            
            # Parse headers
            response_text = response.decode('utf-8', errors='ignore')
            lines = response_text.split('\r\n')
            
            for line in lines[1:]:  # Skip status line
                if ':' in line:
                    key, value = line.split(':', 1)
                    headers[key.strip().lower()] = value.strip()
            
            sock.close()
        
        except Exception as e:
            self.logger.debug(f"HTTP header grab failed: {str(e)}")
        
        return headers
