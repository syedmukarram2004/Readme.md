"""
Technology Detection Module for ReconWizard

Performs comprehensive technology detection on web applications including
web servers, frameworks, CMS, JavaScript libraries, and other technologies.
Uses multiple detection techniques including header analysis and fingerprinting.
"""

import requests
import re
import json
import hashlib
from urllib.parse import urljoin, urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import ssl
import socket


class TechDetector:
    """Technology detection functionality"""
    
    def __init__(self, logger):
        """
        Initialize technology detection module
        
        Args:
            logger: Logger instance for output
        """
        self.logger = logger
        self.timeout = 15
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'ReconWizard/1.0 (Security Research Tool)',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'close'
        })
        
        # Technology fingerprints
        self.tech_patterns = self._load_tech_patterns()
    
    def detect(self, target):
        """
        Perform comprehensive technology detection
        
        Args:
            target (str): Target domain to analyze
        
        Returns:
            dict: Detected technologies organized by category
        """
        self.logger.info(f"Starting technology detection for {target}")
        
        results = {
            'web_servers': [],
            'frameworks': [],
            'cms': [],
            'javascript_libraries': [],
            'databases': [],
            'analytics': [],
            'cdn': [],
            'security': [],
            'other': []
        }
        
        # Ensure target has protocol
        if not target.startswith(('http://', 'https://')):
            target_urls = [f"https://{target}", f"http://{target}"]
        else:
            target_urls = [target]
        
        # Try both HTTP and HTTPS
        for url in target_urls:
            try:
                self.logger.debug(f"Analyzing {url}")
                
                # Get page content and headers
                response = self._safe_request(url)
                if response:
                    # Analyze HTTP headers
                    header_techs = self._analyze_headers(response.headers)
                    self._merge_results(results, header_techs)
                    
                    # Analyze HTML content
                    content_techs = self._analyze_content(response.text)
                    self._merge_results(results, content_techs)
                    
                    # Analyze cookies
                    cookie_techs = self._analyze_cookies(response.cookies)
                    self._merge_results(results, cookie_techs)
                    
                    # Check for common paths and files
                    path_techs = self._check_common_paths(url)
                    self._merge_results(results, path_techs)
                    
                    # If we got successful results, break (prefer HTTPS)
                    if any(results.values()):
                        break
            
            except Exception as e:
                self.logger.debug(f"Analysis failed for {url}: {str(e)}")
                continue
        
        # External API detection (if available)
        try:
            api_techs = self._external_api_detection(target)
            self._merge_results(results, api_techs)
        except Exception as e:
            self.logger.debug(f"External API detection failed: {str(e)}")
        
        # SSL/TLS analysis
        try:
            ssl_techs = self._analyze_ssl(target)
            self._merge_results(results, ssl_techs)
        except Exception as e:
            self.logger.debug(f"SSL analysis failed: {str(e)}")
        
        # Remove duplicates and clean up results
        for category in results:
            results[category] = list(set(results[category]))
        
        total_techs = sum(len(techs) for techs in results.values())
        self.logger.info(f"Technology detection completed. Found {total_techs} technologies")
        
        return results
    
    def _safe_request(self, url):
        """
        Make a safe HTTP request with error handling
        
        Args:
            url (str): URL to request
        
        Returns:
            requests.Response or None: Response object or None if failed
        """
        try:
            response = self.session.get(
                url,
                timeout=self.timeout,
                verify=False,  # Ignore SSL verification for recon
                allow_redirects=True,
                stream=False
            )
            return response
        except Exception as e:
            self.logger.debug(f"Request failed for {url}: {str(e)}")
            return None
    
    def _analyze_headers(self, headers):
        """
        Analyze HTTP headers for technology indicators
        
        Args:
            headers: HTTP response headers
        
        Returns:
            dict: Detected technologies from headers
        """
        results = {
            'web_servers': [],
            'frameworks': [],
            'cms': [],
            'javascript_libraries': [],
            'databases': [],
            'analytics': [],
            'cdn': [],
            'security': [],
            'other': []
        }
        
        # Convert headers to lowercase dict for easier matching
        headers_lower = {k.lower(): v for k, v in headers.items()}
        
        # Web server detection
        server_header = headers_lower.get('server', '')
        if server_header:
            server_patterns = {
                r'apache[/\s]*([\d.]+)?': 'Apache',
                r'nginx[/\s]*([\d.]+)?': 'Nginx',
                r'microsoft-iis[/\s]*([\d.]+)?': 'Microsoft IIS',
                r'lighttpd[/\s]*([\d.]+)?': 'Lighttpd',
                r'cloudflare': 'Cloudflare',
                r'openresty': 'OpenResty',
                r'gunicorn': 'Gunicorn',
                r'uwsgi': 'uWSGI'
            }
            
            for pattern, tech in server_patterns.items():
                match = re.search(pattern, server_header, re.IGNORECASE)
                if match:
                    version = match.group(1) if match.groups() and match.group(1) else ''
                    tech_name = f"{tech} {version}".strip()
                    results['web_servers'].append(tech_name)
        
        # Framework detection from headers
        framework_headers = {
            'x-powered-by': {
                r'php[/\s]*([\d.]+)?': 'PHP',
                r'asp\.net': 'ASP.NET',
                r'express': 'Express.js',
                r'django': 'Django',
                r'flask': 'Flask',
                r'rails': 'Ruby on Rails',
                r'laravel': 'Laravel',
                r'symfony': 'Symfony'
            },
            'x-aspnet-version': {
                r'[\d.]+': 'ASP.NET'
            },
            'x-generator': {
                r'drupal\s*([\d.]+)?': 'Drupal',
                r'wordpress\s*([\d.]+)?': 'WordPress',
                r'joomla\s*([\d.]+)?': 'Joomla'
            }
        }
        
        for header_name, patterns in framework_headers.items():
            header_value = headers_lower.get(header_name, '')
            if header_value:
                for pattern, tech in patterns.items():
                    match = re.search(pattern, header_value, re.IGNORECASE)
                    if match:
                        version = match.group(1) if match.groups() and match.group(1) else ''
                        tech_name = f"{tech} {version}".strip()
                        results['frameworks'].append(tech_name)
        
        # CDN detection
        cdn_headers = [
            'cf-ray', 'cf-cache-status',  # Cloudflare
            'x-cache', 'x-served-by',     # Various CDNs
            'x-amz-cf-id',                # Amazon CloudFront
            'x-azure-ref'                 # Azure CDN
        ]
        
        for header in cdn_headers:
            if header in headers_lower:
                if 'cf-' in header:
                    results['cdn'].append('Cloudflare')
                elif 'amz-cf' in header:
                    results['cdn'].append('Amazon CloudFront')
                elif 'azure' in header:
                    results['cdn'].append('Azure CDN')
                else:
                    results['cdn'].append('CDN detected')
        
        # Security headers
        security_headers = {
            'x-frame-options': 'X-Frame-Options',
            'x-xss-protection': 'XSS Protection',
            'x-content-type-options': 'Content Type Options',
            'strict-transport-security': 'HSTS',
            'content-security-policy': 'Content Security Policy',
            'x-permitted-cross-domain-policies': 'Cross Domain Policy'
        }
        
        for header, tech in security_headers.items():
            if header in headers_lower:
                results['security'].append(tech)
        
        return results
    
    def _analyze_content(self, content):
        """
        Analyze HTML content for technology indicators
        
        Args:
            content (str): HTML content
        
        Returns:
            dict: Detected technologies from content
        """
        results = {
            'web_servers': [],
            'frameworks': [],
            'cms': [],
            'javascript_libraries': [],
            'databases': [],
            'analytics': [],
            'cdn': [],
            'security': [],
            'other': []
        }
        
        if not content:
            return results
        
        # CMS detection patterns
        cms_patterns = {
            r'wp-content|wp-includes|wordpress': 'WordPress',
            r'drupal\.js|drupal\.css|sites/default': 'Drupal',
            r'joomla|option=com_|index\.php\?option': 'Joomla',
            r'typo3|typo3conf': 'TYPO3',
            r'concrete5|concrete/themes': 'Concrete5',
            r'silverstripe|sapphire': 'SilverStripe'
        }
        
        for pattern, cms in cms_patterns.items():
            if re.search(pattern, content, re.IGNORECASE):
                results['cms'].append(cms)
        
        # JavaScript library detection
        js_patterns = {
            r'jquery[.-]([.\d]+)': 'jQuery',
            r'angular[.-]([.\d]+)': 'AngularJS',
            r'react[.-]([.\d]+)': 'React',
            r'vue[.-]([.\d]+)': 'Vue.js',
            r'bootstrap[.-]([.\d]+)': 'Bootstrap',
            r'modernizr[.-]([.\d]+)': 'Modernizr',
            r'underscore[.-]([.\d]+)': 'Underscore.js',
            r'lodash[.-]([.\d]+)': 'Lodash',
            r'd3[.-]([.\d]+)': 'D3.js'
        }
        
        for pattern, lib in js_patterns.items():
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                version = matches[0] if matches[0] else ''
                lib_name = f"{lib} {version}".strip()
                results['javascript_libraries'].append(lib_name)
        
        # Analytics detection
        analytics_patterns = {
            r'google-analytics\.com|gtag\(|ga\(': 'Google Analytics',
            r'googletagmanager\.com': 'Google Tag Manager',
            r'facebook\.net/.*?analytics': 'Facebook Analytics',
            r'hotjar\.com': 'Hotjar',
            r'mixpanel\.com': 'Mixpanel',
            r'segment\.com': 'Segment'
        }
        
        for pattern, analytics in analytics_patterns.items():
            if re.search(pattern, content, re.IGNORECASE):
                results['analytics'].append(analytics)
        
        # Framework detection from meta tags and comments
        meta_patterns = {
            r'<meta[^>]*generator[^>]*content[^>]*wordpress': 'WordPress',
            r'<meta[^>]*generator[^>]*content[^>]*drupal': 'Drupal',
            r'<meta[^>]*generator[^>]*content[^>]*joomla': 'Joomla',
            r'<!--.*?built with django': 'Django',
            r'<!--.*?powered by.*?wordpress': 'WordPress'
        }
        
        for pattern, framework in meta_patterns.items():
            if re.search(pattern, content, re.IGNORECASE):
                results['frameworks'].append(framework)
        
        return results
    
    def _analyze_cookies(self, cookies):
        """
        Analyze cookies for technology indicators
        
        Args:
            cookies: Response cookies
        
        Returns:
            dict: Detected technologies from cookies
        """
        results = {
            'web_servers': [],
            'frameworks': [],
            'cms': [],
            'javascript_libraries': [],
            'databases': [],
            'analytics': [],
            'cdn': [],
            'security': [],
            'other': []
        }
        
        if not cookies:
            return results
        
        cookie_patterns = {
            'PHPSESSID': 'PHP',
            'JSESSIONID': 'Java',
            'ASP.NET_SessionId': 'ASP.NET',
            'CFID': 'ColdFusion',
            'wordpress_': 'WordPress',
            'wp-': 'WordPress',
            'Drupal.toolbar.': 'Drupal',
            '_ga': 'Google Analytics',
            '_gid': 'Google Analytics',
            'hubspotutk': 'HubSpot'
        }
        
        for cookie in cookies:
            for pattern, tech in cookie_patterns.items():
                if pattern.lower() in cookie.name.lower():
                    results['frameworks'].append(tech)
        
        return results
    
    def _check_common_paths(self, base_url):
        """
        Check for common paths and files that indicate technologies
        
        Args:
            base_url (str): Base URL to check
        
        Returns:
            dict: Detected technologies from paths
        """
        results = {
            'web_servers': [],
            'frameworks': [],
            'cms': [],
            'javascript_libraries': [],
            'databases': [],
            'analytics': [],
            'cdn': [],
            'security': [],
            'other': []
        }
        
        common_paths = {
            '/wp-admin/': 'WordPress',
            '/wp-content/': 'WordPress',
            '/wp-includes/': 'WordPress',
            '/admin/': 'Generic Admin',
            '/administrator/': 'Joomla',
            '/sites/default/': 'Drupal',
            '/user/login': 'Drupal',
            '/typo3/': 'TYPO3',
            '/umbraco/': 'Umbraco'
        }
        
        for path, tech in common_paths.items():
            try:
                url = urljoin(base_url, path)
                response = self._safe_request(url)
                if response and response.status_code in [200, 301, 302, 403]:
                    results['cms'].append(tech)
            except Exception:
                continue
        
        return results
    
    def _external_api_detection(self, target):
        """
        Use external APIs for technology detection
        
        Args:
            target (str): Target domain
        
        Returns:
            dict: Detected technologies from external APIs
        """
        results = {
            'web_servers': [],
            'frameworks': [],
            'cms': [],
            'javascript_libraries': [],
            'databases': [],
            'analytics': [],
            'cdn': [],
            'security': [],
            'other': []
        }
        
        try:
            # Builtwith API (limited free tier)
            url = f"https://api.builtwith.com/free1/api.json?KEY=&LOOKUP={target}"
            response = self._safe_request(url)
            
            if response and response.status_code == 200:
                data = response.json()
                if 'Results' in data and data['Results']:
                    for result in data['Results']:
                        if 'Result' in result and 'Paths' in result['Result']:
                            for path in result['Result']['Paths']:
                                if 'Technologies' in path:
                                    for tech in path['Technologies']:
                                        tech_name = tech.get('Name', '')
                                        categories = tech.get('Categories', [])
                                        
                                        if tech_name:
                                            # Categorize based on technology type
                                            if any('server' in cat.lower() for cat in categories):
                                                results['web_servers'].append(tech_name)
                                            elif any('framework' in cat.lower() for cat in categories):
                                                results['frameworks'].append(tech_name)
                                            elif any('cms' in cat.lower() for cat in categories):
                                                results['cms'].append(tech_name)
                                            else:
                                                results['other'].append(tech_name)
        
        except Exception as e:
            self.logger.debug(f"External API detection failed: {str(e)}")
        
        return results
    
    def _analyze_ssl(self, target):
        """
        Analyze SSL/TLS certificate for technology indicators
        
        Args:
            target (str): Target domain
        
        Returns:
            dict: Detected technologies from SSL analysis
        """
        results = {
            'web_servers': [],
            'frameworks': [],
            'cms': [],
            'javascript_libraries': [],
            'databases': [],
            'analytics': [],
            'cdn': [],
            'security': [],
            'other': []
        }
        
        try:
            # Remove protocol if present
            domain = target.replace('https://', '').replace('http://', '')
            
            context = ssl.create_default_context()
            with socket.create_connection((domain, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()
                    
                    if cert:
                        # Check issuer for CDN/security services
                        issuer = dict(x[0] for x in cert.get('issuer', []))
                        issuer_org = issuer.get('organizationName', '').lower()
                        
                        if 'cloudflare' in issuer_org:
                            results['cdn'].append('Cloudflare')
                        elif 'let\'s encrypt' in issuer_org:
                            results['security'].append('Let\'s Encrypt')
                        elif 'digicert' in issuer_org:
                            results['security'].append('DigiCert')
                        
                        # Check Subject Alternative Names for subdomains/services
                        san = cert.get('subjectAltName', [])
                        for name_type, name in san:
                            if name_type == 'DNS':
                                if 'cloudflare' in name:
                                    results['cdn'].append('Cloudflare')
        
        except Exception as e:
            self.logger.debug(f"SSL analysis failed for {target}: {str(e)}")
        
        return results
    
    def _merge_results(self, main_results, new_results):
        """
        Merge new results into main results dictionary
        
        Args:
            main_results (dict): Main results dictionary
            new_results (dict): New results to merge
        """
        for category, techs in new_results.items():
            if category in main_results:
                main_results[category].extend(techs)
    
    def _load_tech_patterns(self):
        """
        Load technology detection patterns
        
        Returns:
            dict: Technology patterns for detection
        """
        return {
            'web_servers': {
                r'apache[/\s]*([\d.]+)?': 'Apache',
                r'nginx[/\s]*([\d.]+)?': 'Nginx',
                r'microsoft-iis[/\s]*([\d.]+)?': 'Microsoft IIS',
                r'lighttpd[/\s]*([\d.]+)?': 'Lighttpd',
                r'openresty': 'OpenResty',
                r'gunicorn': 'Gunicorn',
                r'uwsgi': 'uWSGI'
            },
            'frameworks': {
                r'php[/\s]*([\d.]+)?': 'PHP',
                r'asp\.net': 'ASP.NET',
                r'express': 'Express.js',
                r'django': 'Django',
                r'flask': 'Flask',
                r'rails': 'Ruby on Rails',
                r'laravel': 'Laravel',
                r'symfony': 'Symfony'
            },
            'cms': {
                r'wordpress': 'WordPress',
                r'drupal': 'Drupal',
                r'joomla': 'Joomla',
                r'typo3': 'TYPO3',
                r'concrete5': 'Concrete5'
            },
            'javascript_libraries': {
                r'jquery[.-]([.\d]+)': 'jQuery',
                r'angular[.-]([.\d]+)': 'AngularJS',
                r'react[.-]([.\d]+)': 'React',
                r'vue[.-]([.\d]+)': 'Vue.js',
                r'bootstrap[.-]([.\d]+)': 'Bootstrap'
            }
        }