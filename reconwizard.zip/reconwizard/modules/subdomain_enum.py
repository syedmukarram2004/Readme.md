"""
Subdomain Enumeration Module for ReconWizard

Performs comprehensive subdomain enumeration using multiple techniques including
certificate transparency logs, search engines, and external APIs like crt.sh and AlienVault OTX.
"""

import requests
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse
import ssl
import socket


class SubdomainEnumerator:
    """Subdomain enumeration functionality"""
    
    def __init__(self, logger):
        """
        Initialize subdomain enumeration module
        
        Args:
            logger: Logger instance for output
        """
        self.logger = logger
        self.timeout = 15
        self.found_subdomains = set()
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'ReconWizard/1.0 (Security Research Tool)',
            'Accept': 'application/json, text/html, */*'
        })
    
    def enumerate(self, domain):
        """
        Perform comprehensive subdomain enumeration
        
        Args:
            domain (str): Target domain to enumerate
        
        Returns:
            list: Unique list of discovered subdomains
        """
        self.logger.info(f"Starting subdomain enumeration for {domain}")
        self.found_subdomains.clear()
        
        # Use multiple enumeration techniques
        techniques = [
            ('Certificate Transparency', self._crt_sh_search),
            ('AlienVault OTX', self._otx_search),
            ('Hackertarget', self._hackertarget_search),
            ('ThreatCrowd', self._threatcrowd_search),
            ('DNS Dumpster', self._dnsdumpster_search),
            ('SecurityTrails', self._securitytrails_search),
            ('Google Dorking', self._google_dork_search)
        ]
        
        # Execute techniques with threading
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_technique = {
                executor.submit(technique[1], domain): technique[0] 
                for technique in techniques
            }
            
            for future in as_completed(future_to_technique):
                technique_name = future_to_technique[future]
                try:
                    subdomains = future.result()
                    if subdomains:
                        self.found_subdomains.update(subdomains)
                        self.logger.debug(f"{technique_name} found {len(subdomains)} subdomains")
                except Exception as e:
                    self.logger.debug(f"{technique_name} failed: {str(e)}")
        
        # Validate and resolve subdomains
        validated_subdomains = self._validate_subdomains(list(self.found_subdomains))
        
        self.logger.info(f"Subdomain enumeration completed. Found {len(validated_subdomains)} valid subdomains")
        return sorted(validated_subdomains)
    
    def _crt_sh_search(self, domain):
        """
        Search Certificate Transparency logs via crt.sh
        
        Args:
            domain (str): Target domain
        
        Returns:
            set: Set of discovered subdomains
        """
        subdomains = set()
        
        try:
            url = f"https://crt.sh/?q=%.{domain}&output=json"
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                certificates = response.json()
                for cert in certificates:
                    name_value = cert.get('name_value', '')
                    if name_value:
                        # Split by newlines and clean up
                        for name in name_value.split('\n'):
                            name = name.strip().lower()
                            if name and domain in name:
                                # Remove wildcards and validate
                                if name.startswith('*.'):
                                    name = name[2:]
                                subdomains.add(name)
            
        except Exception as e:
            self.logger.debug(f"crt.sh search failed: {str(e)}")
        
        return subdomains
    
    def _otx_search(self, domain):
        """
        Search AlienVault OTX for subdomains
        
        Args:
            domain (str): Target domain
        
        Returns:
            set: Set of discovered subdomains
        """
        subdomains = set()
        
        try:
            url = f"https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns"
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                if 'passive_dns' in data:
                    for record in data['passive_dns']:
                        hostname = record.get('hostname', '').lower()
                        if hostname and domain in hostname:
                            subdomains.add(hostname)
            
        except Exception as e:
            self.logger.debug(f"OTX search failed: {str(e)}")
        
        return subdomains
    
    def _hackertarget_search(self, domain):
        """
        Search Hackertarget API for subdomains
        
        Args:
            domain (str): Target domain
        
        Returns:
            set: Set of discovered subdomains
        """
        subdomains = set()
        
        try:
            url = f"https://api.hackertarget.com/hostsearch/?q={domain}"
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                lines = response.text.strip().split('\n')
                for line in lines:
                    if ',' in line:
                        hostname = line.split(',')[0].strip().lower()
                        if hostname and domain in hostname:
                            subdomains.add(hostname)
            
        except Exception as e:
            self.logger.debug(f"Hackertarget search failed: {str(e)}")
        
        return subdomains
    
    def _threatcrowd_search(self, domain):
        """
        Search ThreatCrowd API for subdomains
        
        Args:
            domain (str): Target domain
        
        Returns:
            set: Set of discovered subdomains
        """
        subdomains = set()
        
        try:
            url = f"https://www.threatcrowd.org/searchApi/v2/domain/report/?domain={domain}"
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                if 'subdomains' in data:
                    for subdomain in data['subdomains']:
                        if subdomain:
                            subdomains.add(subdomain.lower())
            
        except Exception as e:
            self.logger.debug(f"ThreatCrowd search failed: {str(e)}")
        
        return subdomains
    
    def _dnsdumpster_search(self, domain):
        """
        Search DNS Dumpster for subdomains (requires scraping)
        
        Args:
            domain (str): Target domain
        
        Returns:
            set: Set of discovered subdomains
        """
        subdomains = set()
        
        try:
            # Get CSRF token first
            url = "https://dnsdumpster.com/"
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                # Extract CSRF token
                csrf_token = None
                csrf_match = re.search(r'csrfmiddlewaretoken[\'"][^>]*value=[\'"]([^\'"]*)', response.text)
                if csrf_match:
                    csrf_token = csrf_match.group(1)
                
                if csrf_token:
                    # Submit search form
                    data = {
                        'csrfmiddlewaretoken': csrf_token,
                        'targetip': domain
                    }
                    headers = {
                        'Referer': 'https://dnsdumpster.com/',
                        'Origin': 'https://dnsdumpster.com'
                    }
                    
                    response = self.session.post(url, data=data, headers=headers, timeout=self.timeout)
                    
                    if response.status_code == 200:
                        # Extract subdomains from HTML
                        subdomain_pattern = r'([a-zA-Z0-9.-]+\.' + re.escape(domain) + r')'
                        matches = re.findall(subdomain_pattern, response.text, re.IGNORECASE)
                        for match in matches:
                            subdomains.add(match.lower())
        
        except Exception as e:
            self.logger.debug(f"DNS Dumpster search failed: {str(e)}")
        
        return subdomains
    
    def _securitytrails_search(self, domain):
        """
        Search SecurityTrails API for subdomains
        Note: Requires API key for full functionality
        
        Args:
            domain (str): Target domain
        
        Returns:
            set: Set of discovered subdomains
        """
        subdomains = set()
        
        try:
            # Try public endpoint first (limited results)
            url = f"https://securitytrails.com/list/domain/{domain}"
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                # Extract subdomains from HTML content
                subdomain_pattern = r'([a-zA-Z0-9.-]+\.' + re.escape(domain) + r')'
                matches = re.findall(subdomain_pattern, response.text, re.IGNORECASE)
                for match in matches:
                    if match.lower() not in [domain, f"www.{domain}"]:
                        subdomains.add(match.lower())
        
        except Exception as e:
            self.logger.debug(f"SecurityTrails search failed: {str(e)}")
        
        return subdomains
    
    def _google_dork_search(self, domain):
        """
        Use Google dorking to find subdomains
        
        Args:
            domain (str): Target domain
        
        Returns:
            set: Set of discovered subdomains
        """
        subdomains = set()
        
        try:
            # Google search for subdomains
            queries = [
                f"site:*.{domain}",
                f"site:{domain} -www",
                f"inurl:{domain}"
            ]
            
            for query in queries:
                try:
                    # Note: This is a simplified approach
                    # In practice, you might want to use proper Google API
                    url = f"https://www.google.com/search?q={query}"
                    headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                    
                    response = requests.get(url, headers=headers, timeout=self.timeout)
                    
                    if response.status_code == 200:
                        # Extract potential subdomains from search results
                        subdomain_pattern = r'([a-zA-Z0-9.-]+\.' + re.escape(domain) + r')'
                        matches = re.findall(subdomain_pattern, response.text, re.IGNORECASE)
                        for match in matches:
                            subdomains.add(match.lower())
                    
                    # Add delay to avoid rate limiting
                    time.sleep(2)
                
                except Exception as e:
                    self.logger.debug(f"Google dork query failed: {str(e)}")
        
        except Exception as e:
            self.logger.debug(f"Google dorking failed: {str(e)}")
        
        return subdomains
    
    def _validate_subdomains(self, subdomains):
        """
        Validate subdomains by attempting DNS resolution
        
        Args:
            subdomains (list): List of subdomains to validate
        
        Returns:
            list: List of valid subdomains
        """
        valid_subdomains = []
        
        def validate_subdomain(subdomain):
            try:
                # Clean up subdomain
                subdomain = subdomain.strip().lower()
                if not subdomain:
                    return None
                
                # Remove protocol if present
                if subdomain.startswith('http'):
                    parsed = urlparse(subdomain)
                    subdomain = parsed.netloc
                
                # Simple DNS resolution test
                socket.gethostbyname(subdomain)
                return subdomain
            
            except:
                return None
        
        # Validate subdomains concurrently
        with ThreadPoolExecutor(max_workers=50) as executor:
            future_to_subdomain = {
                executor.submit(validate_subdomain, sub): sub 
                for sub in subdomains
            }
            
            for future in as_completed(future_to_subdomain):
                result = future.result()
                if result:
                    valid_subdomains.append(result)
        
        return valid_subdomains
    
    def certificate_search(self, domain):
        """
        Search SSL certificates for additional subdomains
        
        Args:
            domain (str): Target domain
        
        Returns:
            set: Set of subdomains from certificates
        """
        subdomains = set()
        
        try:
            # Connect to domain and get certificate
            context = ssl.create_default_context()
            with socket.create_connection((domain, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()
                    
                    # Extract Subject Alternative Names
                    if 'subjectAltName' in cert:
                        for alt_name in cert['subjectAltName']:
                            if alt_name[0] == 'DNS':
                                name = alt_name[1].lower()
                                if domain in name:
                                    if name.startswith('*.'):
                                        name = name[2:]
                                    subdomains.add(name)
        
        except Exception as e:
            self.logger.debug(f"Certificate search failed: {str(e)}")
        
        return subdomains
    
    def brute_force_subdomains(self, domain, wordlist=None):
        """
        Brute force subdomains using a wordlist
        
        Args:
            domain (str): Target domain
            wordlist (list): Optional custom wordlist
        
        Returns:
            list: Found subdomains
        """
        if wordlist is None:
            wordlist = [
                'www', 'mail', 'ftp', 'admin', 'test', 'dev', 'staging', 'api', 'blog',
                'shop', 'portal', 'secure', 'vpn', 'cdn', 'assets', 'static', 'media',
                'images', 'beta', 'alpha', 'demo', 'support', 'help', 'docs', 'wiki',
                'forum', 'community', 'chat', 'status', 'monitor', 'metrics', 'analytics'
            ]
        
        found_subdomains = []
        
        def check_subdomain(word):
            subdomain = f"{word}.{domain}"
            try:
                socket.gethostbyname(subdomain)
                return subdomain
            except:
                return None
        
        # Use threading for concurrent checks
        with ThreadPoolExecutor(max_workers=20) as executor:
            future_to_word = {executor.submit(check_subdomain, word): word for word in wordlist}
            
            for future in as_completed(future_to_word):
                result = future.result()
                if result:
                    found_subdomains.append(result)
        
        return found_subdomains
