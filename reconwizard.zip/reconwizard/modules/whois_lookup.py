"""
WHOIS Lookup Module for ReconWizard

Performs WHOIS lookups to gather domain registration information including
registrar details, creation dates, expiration dates, and nameservers.
"""

import whois
import socket
from datetime import datetime


class WhoisLookup:
    """WHOIS lookup functionality"""
    
    def __init__(self, logger):
        """
        Initialize WHOIS lookup module
        
        Args:
            logger: Logger instance for output
        """
        self.logger = logger
    
    def lookup(self, domain):
        """
        Perform WHOIS lookup for a domain
        
        Args:
            domain (str): Target domain to lookup
        
        Returns:
            dict: WHOIS information or error details
        """
        self.logger.info(f"Performing WHOIS lookup for {domain}")
        
        try:
            # Perform WHOIS lookup
            whois_data = whois.whois(domain)
            
            if not whois_data:
                return {'error': 'No WHOIS data found'}
            
            # Extract and format relevant information
            result = {}
            
            # Domain information
            if hasattr(whois_data, 'domain_name') and whois_data.domain_name:
                if isinstance(whois_data.domain_name, list):
                    result['domain_name'] = whois_data.domain_name[0]
                else:
                    result['domain_name'] = whois_data.domain_name
            
            # Registrar information
            if hasattr(whois_data, 'registrar') and whois_data.registrar:
                result['registrar'] = whois_data.registrar
            
            # Registration dates
            if hasattr(whois_data, 'creation_date') and whois_data.creation_date:
                creation_date = whois_data.creation_date
                if isinstance(creation_date, list):
                    creation_date = creation_date[0]
                if isinstance(creation_date, datetime):
                    result['creation_date'] = creation_date.strftime('%Y-%m-%d %H:%M:%S')
                else:
                    result['creation_date'] = str(creation_date)
            
            if hasattr(whois_data, 'expiration_date') and whois_data.expiration_date:
                expiration_date = whois_data.expiration_date
                if isinstance(expiration_date, list):
                    expiration_date = expiration_date[0]
                if isinstance(expiration_date, datetime):
                    result['expiration_date'] = expiration_date.strftime('%Y-%m-%d %H:%M:%S')
                else:
                    result['expiration_date'] = str(expiration_date)
            
            if hasattr(whois_data, 'updated_date') and whois_data.updated_date:
                updated_date = whois_data.updated_date
                if isinstance(updated_date, list):
                    updated_date = updated_date[0]
                if isinstance(updated_date, datetime):
                    result['updated_date'] = updated_date.strftime('%Y-%m-%d %H:%M:%S')
                else:
                    result['updated_date'] = str(updated_date)
            
            # Nameservers
            if hasattr(whois_data, 'name_servers') and whois_data.name_servers:
                if isinstance(whois_data.name_servers, list):
                    result['name_servers'] = [ns.lower() for ns in whois_data.name_servers]
                else:
                    result['name_servers'] = [whois_data.name_servers.lower()]
            
            # Status
            if hasattr(whois_data, 'status') and whois_data.status:
                if isinstance(whois_data.status, list):
                    result['status'] = whois_data.status
                else:
                    result['status'] = [whois_data.status]
            
            # Contact information (if available)
            if hasattr(whois_data, 'org') and whois_data.org:
                result['organization'] = whois_data.org
            
            if hasattr(whois_data, 'country') and whois_data.country:
                result['country'] = whois_data.country
                
            if hasattr(whois_data, 'state') and whois_data.state:
                result['state'] = whois_data.state
                
            if hasattr(whois_data, 'city') and whois_data.city:
                result['city'] = whois_data.city
            
            # DNSSEC information
            if hasattr(whois_data, 'dnssec') and whois_data.dnssec:
                result['dnssec'] = whois_data.dnssec
            
            # Add IP resolution
            try:
                ip_address = socket.gethostbyname(domain)
                result['resolved_ip'] = ip_address
                self.logger.debug(f"Domain {domain} resolves to {ip_address}")
            except socket.gaierror:
                self.logger.warning(f"Could not resolve IP for {domain}")
                result['resolved_ip'] = 'Could not resolve'
            
            self.logger.info(f"WHOIS lookup completed for {domain}")
            return result
            
        except Exception as e:
            error_msg = f"WHOIS lookup failed for {domain}: {str(e)}"
            self.logger.error(error_msg)
            return {'error': error_msg}
    
    def bulk_lookup(self, domains):
        """
        Perform WHOIS lookup for multiple domains
        
        Args:
            domains (list): List of domains to lookup
        
        Returns:
            dict: Dictionary with domain as key and WHOIS data as value
        """
        results = {}
        
        for domain in domains:
            self.logger.info(f"Processing WHOIS for {domain}")
            results[domain] = self.lookup(domain)
        
        return results
    
    def is_domain_expired(self, domain):
        """
        Check if a domain is expired based on WHOIS data
        
        Args:
            domain (str): Domain to check
        
        Returns:
            bool: True if expired, False if not expired, None if cannot determine
        """
        try:
            whois_data = self.lookup(domain)
            
            if 'error' in whois_data or 'expiration_date' not in whois_data:
                return None
            
            expiration_str = whois_data['expiration_date']
            expiration_date = datetime.strptime(expiration_str, '%Y-%m-%d %H:%M:%S')
            
            return datetime.now() > expiration_date
            
        except Exception as e:
            self.logger.error(f"Could not determine expiration status for {domain}: {str(e)}")
            return None
    
    def get_domain_age(self, domain):
        """
        Calculate domain age in days
        
        Args:
            domain (str): Domain to check
        
        Returns:
            int: Age in days, or None if cannot determine
        """
        try:
            whois_data = self.lookup(domain)
            
            if 'error' in whois_data or 'creation_date' not in whois_data:
                return None
            
            creation_str = whois_data['creation_date']
            creation_date = datetime.strptime(creation_str, '%Y-%m-%d %H:%M:%S')
            
            age = datetime.now() - creation_date
            return age.days
            
        except Exception as e:
            self.logger.error(f"Could not determine age for {domain}: {str(e)}")
            return None
