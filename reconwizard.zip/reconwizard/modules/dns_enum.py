"""
DNS Enumeration Module for ReconWizard

Performs comprehensive DNS record enumeration including A, AAAA, MX, TXT, NS, 
CNAME, SOA, and PTR records to gather detailed DNS infrastructure information.
"""

import dns.resolver
import dns.reversename
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed


class DNSEnumerator:
    """DNS enumeration functionality"""
    
    def __init__(self, logger):
        """
        Initialize DNS enumeration module
        
        Args:
            logger: Logger instance for output
        """
        self.logger = logger
        self.record_types = ['A', 'AAAA', 'MX', 'TXT', 'NS', 'CNAME', 'SOA', 'SRV']
        self.timeout = 10
    
    def enumerate(self, domain):
        """
        Perform comprehensive DNS enumeration for a domain
        
        Args:
            domain (str): Target domain to enumerate
        
        Returns:
            dict: DNS records organized by type
        """
        self.logger.info(f"Starting DNS enumeration for {domain}")
        
        results = {}
        
        # Enumerate each record type
        for record_type in self.record_types:
            try:
                records = self._query_record_type(domain, record_type)
                if records:
                    results[record_type] = records
                    self.logger.debug(f"Found {len(records)} {record_type} records")
            except Exception as e:
                self.logger.debug(f"No {record_type} records found for {domain}: {str(e)}")
                results[record_type] = []
        
        # Perform reverse DNS lookup if A record exists
        if 'A' in results and results['A']:
            try:
                ip_address = results['A'][0]  # Use first A record
                ptr_record = self._reverse_dns_lookup(ip_address)
                if ptr_record:
                    results['PTR'] = [ptr_record]
            except Exception as e:
                self.logger.debug(f"Reverse DNS lookup failed: {str(e)}")
        
        # Check for common DNS security records
        security_records = self._check_security_records(domain)
        results.update(security_records)
        
        self.logger.info(f"DNS enumeration completed for {domain}")
        return results
    
    def _query_record_type(self, domain, record_type):
        """
        Query specific DNS record type
        
        Args:
            domain (str): Target domain
            record_type (str): DNS record type to query
        
        Returns:
            list: List of DNS records
        """
        records = []
        
        try:
            resolver = dns.resolver.Resolver()
            resolver.timeout = self.timeout
            resolver.lifetime = self.timeout
            
            answers = resolver.resolve(domain, record_type)
            
            for answer in answers:
                if record_type == 'MX':
                    records.append(f"{answer.preference} {answer.exchange}")
                elif record_type == 'SOA':
                    records.append(f"{answer.mname} {answer.rname} {answer.serial}")
                elif record_type == 'SRV':
                    records.append(f"{answer.priority} {answer.weight} {answer.port} {answer.target}")
                else:
                    records.append(str(answer))
        
        except dns.resolver.NXDOMAIN:
            self.logger.debug(f"Domain {domain} does not exist")
        except dns.resolver.NoAnswer:
            self.logger.debug(f"No {record_type} records found for {domain}")
        except dns.resolver.Timeout:
            self.logger.warning(f"DNS query timeout for {domain} {record_type}")
        except Exception as e:
            self.logger.debug(f"DNS query error for {domain} {record_type}: {str(e)}")
        
        return records
    
    def _reverse_dns_lookup(self, ip_address):
        """
        Perform reverse DNS lookup
        
        Args:
            ip_address (str): IP address to lookup
        
        Returns:
            str: PTR record or None
        """
        try:
            reversed_ip = dns.reversename.from_address(ip_address)
            resolver = dns.resolver.Resolver()
            resolver.timeout = self.timeout
            
            answers = resolver.resolve(reversed_ip, 'PTR')
            return str(answers[0])
        
        except Exception as e:
            self.logger.debug(f"Reverse DNS lookup failed for {ip_address}: {str(e)}")
            return None
    
    def _check_security_records(self, domain):
        """
        Check for DNS security-related records
        
        Args:
            domain (str): Target domain
        
        Returns:
            dict: Security-related DNS records
        """
        security_records = {}
        
        # Check for SPF records in TXT
        spf_records = []
        txt_records = self._query_record_type(domain, 'TXT')
        for record in txt_records:
            if 'v=spf1' in record.lower():
                spf_records.append(record)
        
        if spf_records:
            security_records['SPF'] = spf_records
        
        # Check for DMARC records
        dmarc_domain = f"_dmarc.{domain}"
        dmarc_records = self._query_record_type(dmarc_domain, 'TXT')
        dmarc_policies = []
        for record in dmarc_records:
            if 'v=DMARC1' in record:
                dmarc_policies.append(record)
        
        if dmarc_policies:
            security_records['DMARC'] = dmarc_policies
        
        # Check for DKIM records (common selectors)
        dkim_selectors = ['default', 'google', 'selector1', 'selector2', 'k1', 's1', 's2']
        dkim_records = []
        
        for selector in dkim_selectors:
            dkim_domain = f"{selector}._domainkey.{domain}"
            records = self._query_record_type(dkim_domain, 'TXT')
            for record in records:
                if 'v=DKIM1' in record or 'k=' in record:
                    dkim_records.append(f"{selector}: {record}")
        
        if dkim_records:
            security_records['DKIM'] = dkim_records
        
        # Check for CAA records
        caa_records = self._query_record_type(domain, 'CAA')
        if caa_records:
            security_records['CAA'] = caa_records
        
        return security_records
    
    def zone_transfer_attempt(self, domain):
        """
        Attempt DNS zone transfer (AXFR)
        
        Args:
            domain (str): Target domain
        
        Returns:
            list: Zone transfer results or empty list
        """
        self.logger.info(f"Attempting zone transfer for {domain}")
        
        results = []
        
        # Get NS records first
        ns_records = self._query_record_type(domain, 'NS')
        
        if not ns_records:
            self.logger.warning(f"No NS records found for {domain}")
            return results
        
        # Try zone transfer on each nameserver
        for ns in ns_records:
            try:
                self.logger.debug(f"Trying zone transfer from {ns}")
                
                # Resolve nameserver to IP
                ns_ip = socket.gethostbyname(str(ns).rstrip('.'))
                
                # Attempt zone transfer
                zone = dns.zone.from_xfr(dns.query.xfr(ns_ip, domain))
                
                if zone:
                    self.logger.warning(f"Zone transfer successful from {ns}!")
                    for name, node in zone.nodes.items():
                        for rdataset in node.rdatasets:
                            results.append(f"{name}.{domain} {rdataset}")
                
            except Exception as e:
                self.logger.debug(f"Zone transfer failed for {ns}: {str(e)}")
        
        if not results:
            self.logger.info("Zone transfer not allowed (this is expected)")
        
        return results
    
    def dns_bruteforce(self, domain, wordlist=None):
        """
        Perform DNS bruteforce for common subdomains
        
        Args:
            domain (str): Target domain
            wordlist (list): Optional custom wordlist
        
        Returns:
            list: Found subdomains
        """
        if wordlist is None:
            wordlist = [
                'www', 'mail', 'ftp', 'localhost', 'webmail', 'smtp', 'pop', 'ns1', 'webdisk',
                'ns2', 'cpanel', 'whm', 'autodiscover', 'autoconfig', 'mx', 'email', 'imap',
                'pop3', 'admin', 'administrator', 'api', 'blog', 'dev', 'stage', 'staging',
                'test', 'secure', 'ssl', 'shop', 'beta', 'mobile', 'm', 'support', 'help',
                'portal', 'vpn', 'git', 'svn', 'cdn', 'assets', 'static', 'media', 'images'
            ]
        
        self.logger.info(f"DNS bruteforcing {domain} with {len(wordlist)} words")
        
        found_subdomains = []
        
        def check_subdomain(word):
            subdomain = f"{word}.{domain}"
            try:
                resolver = dns.resolver.Resolver()
                resolver.timeout = 3
                resolver.lifetime = 3
                
                answers = resolver.resolve(subdomain, 'A')
                if answers:
                    ip = str(answers[0])
                    return (subdomain, ip)
            except:
                pass
            return None
        
        # Use ThreadPoolExecutor for concurrent DNS queries
        with ThreadPoolExecutor(max_workers=20) as executor:
            future_to_word = {executor.submit(check_subdomain, word): word for word in wordlist}
            
            for future in as_completed(future_to_word):
                result = future.result()
                if result:
                    subdomain, ip = result
                    found_subdomains.append(f"{subdomain} -> {ip}")
                    self.logger.debug(f"Found subdomain: {subdomain} -> {ip}")
        
        self.logger.info(f"DNS bruteforce completed. Found {len(found_subdomains)} subdomains")
        return found_subdomains
    
    def check_wildcard(self, domain):
        """
        Check if domain has wildcard DNS records
        
        Args:
            domain (str): Target domain
        
        Returns:
            bool: True if wildcard exists, False otherwise
        """
        try:
            # Generate random subdomain
            import random
            import string
            random_subdomain = ''.join(random.choices(string.ascii_lowercase + string.digits, k=20))
            test_domain = f"{random_subdomain}.{domain}"
            
            resolver = dns.resolver.Resolver()
            resolver.timeout = 5
            
            answers = resolver.resolve(test_domain, 'A')
            if answers:
                self.logger.warning(f"Wildcard DNS detected for {domain}")
                return True
        
        except:
            pass
        
        return False
