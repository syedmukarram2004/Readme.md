"""
Utility functions for ReconWizard

This module contains common utility functions used across the reconnaissance tool.
"""

import logging
import re
import socket
import requests
from datetime import datetime
import os


def setup_logging(verbosity=1):
    """
    Setup logging configuration based on verbosity level
    
    Args:
        verbosity (int): Logging level (0=ERROR, 1=INFO, 2=DEBUG, 3=TRACE)
    
    Returns:
        logging.Logger: Configured logger instance
    """
    log_levels = {
        0: logging.ERROR,
        1: logging.INFO,
        2: logging.DEBUG,
        3: logging.DEBUG  # Most verbose
    }
    
    level = log_levels.get(verbosity, logging.INFO)
    
    # Create logger
    logger = logging.getLogger('ReconWizard')
    logger.setLevel(level)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    
    # Create formatter
    if verbosity >= 2:
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
        )
    else:
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
    
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    return logger


def validate_domain(domain):
    """
    Validate domain format using regex
    
    Args:
        domain (str): Domain to validate
    
    Returns:
        bool: True if domain is valid, False otherwise
    """
    # Basic domain validation regex
    domain_pattern = re.compile(
        r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    )
    
    if not domain or len(domain) > 253:
        return False
    
    return bool(domain_pattern.match(domain))


def resolve_domain(domain):
    """
    Resolve domain to IP address
    
    Args:
        domain (str): Domain to resolve
    
    Returns:
        str: IP address or None if resolution fails
    """
    try:
        return socket.gethostbyname(domain)
    except socket.gaierror:
        return None


def is_port_open(host, port, timeout=3):
    """
    Check if a port is open on a host
    
    Args:
        host (str): Target host
        port (int): Port number to check
        timeout (int): Connection timeout in seconds
    
    Returns:
        bool: True if port is open, False otherwise
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception:
        return False


def safe_request(url, timeout=10, headers=None):
    """
    Make a safe HTTP request with error handling
    
    Args:
        url (str): URL to request
        timeout (int): Request timeout in seconds
        headers (dict): Optional headers
    
    Returns:
        requests.Response or None: Response object or None if failed
    """
    try:
        default_headers = {
            'User-Agent': 'ReconWizard/1.0 (Security Research Tool)',
            'Accept': 'application/json, text/html, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'close'
        }
        
        if headers:
            default_headers.update(headers)
        
        response = requests.get(
            url, 
            timeout=timeout, 
            headers=default_headers,
            verify=True,
            allow_redirects=True
        )
        
        return response
    
    except requests.RequestException:
        return None


def format_timestamp(timestamp=None):
    """
    Format timestamp for reports
    
    Args:
        timestamp (datetime): Timestamp to format, defaults to now
    
    Returns:
        str: Formatted timestamp string
    """
    if timestamp is None:
        timestamp = datetime.now()
    
    return timestamp.strftime("%Y-%m-%d %H:%M:%S UTC")


def generate_report(results, output_file, format_type='txt'):
    """
    Generate reconnaissance report in specified format
    
    Args:
        results (dict): Reconnaissance results
        output_file (str): Output file path
        format_type (str): Report format ('txt' or 'html')
    """
    if format_type == 'txt':
        _generate_txt_report(results, output_file)
    elif format_type == 'html':
        _generate_html_report(results, output_file)
    else:
        raise ValueError(f"Unsupported report format: {format_type}")


def _generate_txt_report(results, output_file):
    """Generate text report"""
    with open(output_file, 'w') as f:
        f.write("=" * 80 + "\n")
        f.write("RECONWIZARD RECONNAISSANCE REPORT\n")
        f.write("=" * 80 + "\n\n")
        
        f.write(f"Target: {results['target']}\n")
        f.write(f"Scan Date: {results['timestamp']}\n")
        f.write(f"Generated: {format_timestamp()}\n\n")
        
        # WHOIS Information
        f.write("-" * 40 + "\n")
        f.write("WHOIS INFORMATION\n")
        f.write("-" * 40 + "\n")
        if 'error' in results['whois']:
            f.write(f"Error: {results['whois']['error']}\n")
        else:
            for key, value in results['whois'].items():
                if value:
                    f.write(f"{key.title()}: {value}\n")
        f.write("\n")
        
        # DNS Records
        f.write("-" * 40 + "\n")
        f.write("DNS RECORDS\n")
        f.write("-" * 40 + "\n")
        if 'error' in results['dns']:
            f.write(f"Error: {results['dns']['error']}\n")
        else:
            for record_type, records in results['dns'].items():
                if records:
                    f.write(f"{record_type} Records:\n")
                    for record in records:
                        f.write(f"  - {record}\n")
                    f.write("\n")
        
        # Subdomains
        f.write("-" * 40 + "\n")
        f.write("SUBDOMAINS\n")
        f.write("-" * 40 + "\n")
        if results['subdomains']:
            for subdomain in results['subdomains']:
                f.write(f"  - {subdomain}\n")
            f.write(f"\nTotal subdomains found: {len(results['subdomains'])}\n")
        else:
            f.write("No subdomains found.\n")
        f.write("\n")
        
        # Port Scan Results
        f.write("-" * 40 + "\n")
        f.write("PORT SCAN RESULTS\n")
        f.write("-" * 40 + "\n")
        if results['ports']:
            open_ports = [p for p in results['ports'] if p['status'] == 'open']
            f.write(f"Open ports found: {len(open_ports)}\n\n")
            for port in open_ports:
                f.write(f"Port {port['port']}/{port['protocol']}: {port['status']}")
                if 'service' in port:
                    f.write(f" ({port['service']})")
                f.write("\n")
        else:
            f.write("No port scan performed or no open ports found.\n")
        f.write("\n")
        
        # Banner Information
        f.write("-" * 40 + "\n")
        f.write("BANNER INFORMATION\n")
        f.write("-" * 40 + "\n")
        if results['banners']:
            for port, banner in results['banners'].items():
                f.write(f"Port {port}:\n")
                f.write(f"  {banner}\n\n")
        else:
            f.write("No banner information available.\n")
        f.write("\n")
        
        # Technology Detection
        f.write("-" * 40 + "\n")
        f.write("TECHNOLOGY DETECTION\n")
        f.write("-" * 40 + "\n")
        if results['technologies']:
            for category, techs in results['technologies'].items():
                if techs:
                    f.write(f"{category.title()}:\n")
                    for tech in techs:
                        f.write(f"  - {tech}\n")
                    f.write("\n")
        else:
            f.write("No technologies detected.\n")
        
        f.write("\n" + "=" * 80 + "\n")
        f.write("End of Report\n")
        f.write("=" * 80 + "\n")


def _generate_html_report(results, output_file):
    """Generate HTML report"""
    html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ReconWizard Report - {target}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }}
        .header {{
            text-align: center;
            border-bottom: 3px solid #007acc;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }}
        .header h1 {{
            color: #007acc;
            margin: 0;
            font-size: 2.5em;
        }}
        .header .subtitle {{
            color: #666;
            font-size: 1.2em;
            margin-top: 10px;
        }}
        .section {{
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #fafafa;
        }}
        .section h2 {{
            color: #007acc;
            border-bottom: 2px solid #007acc;
            padding-bottom: 10px;
            margin-top: 0;
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 10px;
            margin: 15px 0;
        }}
        .info-label {{
            font-weight: bold;
            color: #333;
        }}
        .info-value {{
            color: #666;
        }}
        .list-item {{
            background-color: white;
            padding: 8px 12px;
            margin: 5px 0;
            border-left: 4px solid #007acc;
            border-radius: 4px;
        }}
        .port-open {{
            color: #d63384;
            font-weight: bold;
        }}
        .port-closed {{
            color: #6c757d;
        }}
        .error {{
            color: #dc3545;
            font-style: italic;
            background-color: #f8d7da;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #f5c6cb;
        }}
        .stats {{
            display: flex;
            justify-content: space-around;
            background-color: #007acc;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }}
        .stat-item {{
            text-align: center;
        }}
        .stat-value {{
            font-size: 2em;
            font-weight: bold;
        }}
        .stat-label {{
            font-size: 0.9em;
            opacity: 0.9;
        }}
        pre {{
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            border: 1px solid #e9ecef;
            overflow-x: auto;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>ReconWizard Report</h1>
            <div class="subtitle">Reconnaissance Report for {target}</div>
            <div class="info-grid" style="max-width: 400px; margin: 20px auto;">
                <span class="info-label">Scan Date:</span>
                <span class="info-value">{timestamp}</span>
                <span class="info-label">Generated:</span>
                <span class="info-value">{generated}</span>
            </div>
        </div>

        <div class="stats">
            <div class="stat-item">
                <div class="stat-value">{subdomain_count}</div>
                <div class="stat-label">Subdomains</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">{open_port_count}</div>
                <div class="stat-label">Open Ports</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">{tech_count}</div>
                <div class="stat-label">Technologies</div>
            </div>
        </div>

        {whois_section}
        {dns_section}
        {subdomain_section}
        {port_section}
        {banner_section}
        {tech_section}

        <div class="section" style="text-align: center; margin-top: 40px;">
            <p><em>Generated by ReconWizard - Modular Reconnaissance Tool</em></p>
        </div>
    </div>
</body>
</html>
"""
    
    # Calculate statistics
    subdomain_count = len(results['subdomains'])
    open_port_count = len([p for p in results['ports'] if p['status'] == 'open'])
    tech_count = sum(len(techs) for techs in results['technologies'].values() if isinstance(techs, list))
    
    # Generate sections
    sections = {
        'whois_section': _generate_whois_html_section(results['whois']),
        'dns_section': _generate_dns_html_section(results['dns']),
        'subdomain_section': _generate_subdomain_html_section(results['subdomains']),
        'port_section': _generate_port_html_section(results['ports']),
        'banner_section': _generate_banner_html_section(results['banners']),
        'tech_section': _generate_tech_html_section(results['technologies'])
    }
    
    # Format the HTML
    html_content = html_template.format(
        target=results['target'],
        timestamp=results['timestamp'],
        generated=format_timestamp(),
        subdomain_count=subdomain_count,
        open_port_count=open_port_count,
        tech_count=tech_count,
        **sections
    )
    
    with open(output_file, 'w') as f:
        f.write(html_content)


def _generate_whois_html_section(whois_data):
    """Generate WHOIS section for HTML report"""
    if 'error' in whois_data:
        return f"""
        <div class="section">
            <h2>WHOIS Information</h2>
            <div class="error">Error: {whois_data['error']}</div>
        </div>
        """
    
    if not whois_data:
        return """
        <div class="section">
            <h2>WHOIS Information</h2>
            <p>No WHOIS information available.</p>
        </div>
        """
    
    whois_items = ""
    for key, value in whois_data.items():
        if value:
            whois_items += f"""
            <span class="info-label">{key.title()}:</span>
            <span class="info-value">{value}</span>
            """
    
    return f"""
    <div class="section">
        <h2>WHOIS Information</h2>
        <div class="info-grid">
            {whois_items}
        </div>
    </div>
    """


def _generate_dns_html_section(dns_data):
    """Generate DNS section for HTML report"""
    if 'error' in dns_data:
        return f"""
        <div class="section">
            <h2>DNS Records</h2>
            <div class="error">Error: {dns_data['error']}</div>
        </div>
        """
    
    if not dns_data:
        return """
        <div class="section">
            <h2>DNS Records</h2>
            <p>No DNS records found.</p>
        </div>
        """
    
    dns_content = ""
    for record_type, records in dns_data.items():
        if records:
            dns_content += f"<h3>{record_type} Records</h3>"
            for record in records:
                dns_content += f'<div class="list-item">{record}</div>'
    
    return f"""
    <div class="section">
        <h2>DNS Records</h2>
        {dns_content}
    </div>
    """


def _generate_subdomain_html_section(subdomains):
    """Generate subdomains section for HTML report"""
    if not subdomains:
        return """
        <div class="section">
            <h2>Subdomains</h2>
            <p>No subdomains found.</p>
        </div>
        """
    
    subdomain_items = ""
    for subdomain in subdomains:
        subdomain_items += f'<div class="list-item">{subdomain}</div>'
    
    return f"""
    <div class="section">
        <h2>Subdomains ({len(subdomains)} found)</h2>
        {subdomain_items}
    </div>
    """


def _generate_port_html_section(ports):
    """Generate ports section for HTML report"""
    if not ports:
        return """
        <div class="section">
            <h2>Port Scan Results</h2>
            <p>No port scan performed.</p>
        </div>
        """
    
    open_ports = [p for p in ports if p['status'] == 'open']
    
    if not open_ports:
        return """
        <div class="section">
            <h2>Port Scan Results</h2>
            <p>No open ports found.</p>
        </div>
        """
    
    port_items = ""
    for port in open_ports:
        service_info = f" ({port['service']})" if 'service' in port else ""
        port_items += f"""
        <div class="list-item">
            <span class="port-open">Port {port['port']}/{port['protocol']}</span>: {port['status']}{service_info}
        </div>
        """
    
    return f"""
    <div class="section">
        <h2>Port Scan Results ({len(open_ports)} open ports)</h2>
        {port_items}
    </div>
    """


def _generate_banner_html_section(banners):
    """Generate banners section for HTML report"""
    if not banners:
        return """
        <div class="section">
            <h2>Banner Information</h2>
            <p>No banner information available.</p>
        </div>
        """
    
    banner_content = ""
    for port, banner in banners.items():
        banner_content += f"""
        <h3>Port {port}</h3>
        <pre>{banner}</pre>
        """
    
    return f"""
    <div class="section">
        <h2>Banner Information</h2>
        {banner_content}
    </div>
    """


def _generate_tech_html_section(technologies):
    """Generate technologies section for HTML report"""
    if not technologies:
        return """
        <div class="section">
            <h2>Technology Detection</h2>
            <p>No technologies detected.</p>
        </div>
        """
    
    tech_content = ""
    for category, techs in technologies.items():
        if techs:
            tech_content += f"<h3>{category.title()}</h3>"
            for tech in techs:
                tech_content += f'<div class="list-item">{tech}</div>'
    
    return f"""
    <div class="section">
        <h2>Technology Detection</h2>
        {tech_content}
    </div>
    """
