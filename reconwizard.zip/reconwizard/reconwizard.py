#!/usr/bin/env python3
"""
ReconWizard - A Modular Reconnaissance Tool for Penetration Testing

This tool performs passive and active reconnaissance on target domains,
providing comprehensive information gathering capabilities.

Author: ReconWizard Development Team
License: MIT
"""

import argparse
import logging
import sys
import os
import json
from datetime import datetime
from utils import setup_logging, validate_domain, generate_report

# Import reconnaissance modules
from modules.whois_lookup import WhoisLookup
from modules.dns_enum import DNSEnumerator
from modules.subdomain_enum import SubdomainEnumerator
from modules.port_scan import PortScanner
from modules.banner_grab import BannerGrabber
from modules.tech_detect import TechDetector


class ReconWizard:
    """Main reconnaissance orchestrator class"""
    
    def __init__(self, target, verbosity=1):
        """
        Initialize ReconWizard with target domain
        
        Args:
            target (str): Target domain to scan
            verbosity (int): Logging verbosity level (0-3)
        """
        self.target = target
        self.verbosity = verbosity
        self.results = {
            'target': target,
            'timestamp': datetime.now().isoformat(),
            'whois': {},
            'dns': {},
            'subdomains': [],
            'ports': [],
            'banners': {},
            'technologies': {}
        }
        
        # Setup logging
        self.logger = setup_logging(verbosity)
        
        # Initialize modules
        self.whois_lookup = WhoisLookup(self.logger)
        self.dns_enum = DNSEnumerator(self.logger)
        self.subdomain_enum = SubdomainEnumerator(self.logger)
        self.port_scanner = PortScanner(self.logger)
        self.banner_grabber = BannerGrabber(self.logger)
        self.tech_detector = TechDetector(self.logger)
    
    def run_whois(self):
        """Execute WHOIS lookup"""
        self.logger.info(f"Starting WHOIS lookup for {self.target}")
        try:
            self.results['whois'] = self.whois_lookup.lookup(self.target)
            self.logger.info("WHOIS lookup completed successfully")
        except Exception as e:
            self.logger.error(f"WHOIS lookup failed: {str(e)}")
            self.results['whois'] = {'error': str(e)}
    
    def run_dns_enum(self):
        """Execute DNS enumeration"""
        self.logger.info(f"Starting DNS enumeration for {self.target}")
        try:
            self.results['dns'] = self.dns_enum.enumerate(self.target)
            self.logger.info("DNS enumeration completed successfully")
        except Exception as e:
            self.logger.error(f"DNS enumeration failed: {str(e)}")
            self.results['dns'] = {'error': str(e)}
    
    def run_subdomain_enum(self):
        """Execute subdomain enumeration"""
        self.logger.info(f"Starting subdomain enumeration for {self.target}")
        try:
            self.results['subdomains'] = self.subdomain_enum.enumerate(self.target)
            self.logger.info(f"Found {len(self.results['subdomains'])} subdomains")
        except Exception as e:
            self.logger.error(f"Subdomain enumeration failed: {str(e)}")
            self.results['subdomains'] = []
    
    def run_port_scan(self, ports=None):
        """Execute port scanning"""
        self.logger.info(f"Starting port scan for {self.target}")
        try:
            self.results['ports'] = self.port_scanner.scan(self.target, ports)
            open_ports = [p for p in self.results['ports'] if p.get('status') == 'open']
            self.logger.info(f"Found {len(open_ports)} open ports")
        except Exception as e:
            self.logger.error(f"Port scanning failed: {str(e)}")
            self.results['ports'] = []
    
    def run_banner_grab(self):
        """Execute banner grabbing on open ports"""
        if not self.results['ports']:
            self.logger.warning("No ports found for banner grabbing")
            return
            
        self.logger.info("Starting banner grabbing")
        try:
            open_ports = [p for p in self.results['ports'] if p.get('status') == 'open']
            self.results['banners'] = self.banner_grabber.grab_banners(self.target, open_ports)
            self.logger.info(f"Banner grabbing completed for {len(open_ports)} ports")
        except Exception as e:
            self.logger.error(f"Banner grabbing failed: {str(e)}")
            self.results['banners'] = {}
    
    def run_tech_detect(self):
        """Execute technology detection"""
        self.logger.info(f"Starting technology detection for {self.target}")
        try:
            self.results['technologies'] = self.tech_detector.detect(self.target)
            self.logger.info("Technology detection completed successfully")
        except Exception as e:
            self.logger.error(f"Technology detection failed: {str(e)}")
            self.results['technologies'] = {}
    
    def run_all(self, ports=None):
        """Execute all reconnaissance modules"""
        self.logger.info(f"Starting comprehensive reconnaissance for {self.target}")
        
        # Run passive reconnaissance first
        self.run_whois()
        self.run_dns_enum()
        self.run_subdomain_enum()
        
        # Run active reconnaissance
        self.run_port_scan(ports)
        if self.results['ports']:
            self.run_banner_grab()
        self.run_tech_detect()
        
        self.logger.info("Comprehensive reconnaissance completed")
    
    def generate_reports(self, output_dir="reports", format_type="both"):
        """
        Generate reconnaissance reports
        
        Args:
            output_dir (str): Output directory for reports
            format_type (str): Report format ('txt', 'html', 'json', 'both')
        """
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate timestamp for filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_filename = f"{self.target}_{timestamp}"
        
        try:
            # Generate JSON report (always)
            json_file = os.path.join(output_dir, f"{base_filename}.json")
            with open(json_file, 'w') as f:
                json.dump(self.results, f, indent=2, default=str)
            self.logger.info(f"JSON report saved: {json_file}")
            
            # Generate text report
            if format_type in ['txt', 'both']:
                txt_file = os.path.join(output_dir, f"{base_filename}.txt")
                generate_report(self.results, txt_file, 'txt')
                self.logger.info(f"Text report saved: {txt_file}")
            
            # Generate HTML report
            if format_type in ['html', 'both']:
                html_file = os.path.join(output_dir, f"{base_filename}.html")
                generate_report(self.results, html_file, 'html')
                self.logger.info(f"HTML report saved: {html_file}")
        
        except Exception as e:
            self.logger.error(f"Report generation failed: {str(e)}")


def create_parser():
    """Create command line argument parser"""
    parser = argparse.ArgumentParser(
        description="ReconWizard - Modular Reconnaissance Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 reconwizard.py example.com --all
  python3 reconwizard.py example.com --whois --dns
  python3 reconwizard.py example.com --ports --banner
  python3 reconwizard.py example.com --subdomains --tech
        """
    )
    
    # Target argument
    parser.add_argument('target', help='Target domain to scan')
    
    # Module selection
    parser.add_argument('--whois', action='store_true', help='Perform WHOIS lookup')
    parser.add_argument('--dns', action='store_true', help='Perform DNS enumeration')
    parser.add_argument('--subdomains', action='store_true', help='Perform subdomain enumeration')
    parser.add_argument('--ports', action='store_true', help='Perform port scanning')
    parser.add_argument('--banner', action='store_true', help='Perform banner grabbing')
    parser.add_argument('--tech', action='store_true', help='Perform technology detection')
    parser.add_argument('--all', action='store_true', help='Run all reconnaissance modules')
    
    # Port scanning options
    parser.add_argument('--ports-range', default='1-1000', help='Port range for scanning (default: 1-1000)')
    
    # Output options
    parser.add_argument('--output', choices=['txt', 'html', 'json', 'both'], default='both',
                       help='Output format (default: both)')
    parser.add_argument('--output-dir', default='reports', help='Output directory (default: reports)')
    
    # Verbosity options
    parser.add_argument('-v', '--verbose', action='count', default=1,
                       help='Increase verbosity level (use -v, -vv, or -vvv)')
    parser.add_argument('-q', '--quiet', action='store_true',
                       help='Suppress output except errors')
    
    return parser


def parse_port_range(port_range):
    """
    Parse port range string into list of ports
    
    Args:
        port_range (str): Port range string (e.g., "1-1000", "80,443,8080")
    
    Returns:
        list: List of port numbers
    """
    ports = []
    
    try:
        if '-' in port_range:
            # Range format: "1-1000"
            start, end = map(int, port_range.split('-'))
            ports = list(range(start, end + 1))
        elif ',' in port_range:
            # Comma-separated format: "80,443,8080"
            ports = [int(p.strip()) for p in port_range.split(',')]
        else:
            # Single port
            ports = [int(port_range)]
    except ValueError:
        print(f"Error: Invalid port range format: {port_range}")
        sys.exit(1)
    
    return ports


def main():
    """Main entry point for command line usage"""
    parser = create_parser()
    args = parser.parse_args()
    
    # Set verbosity
    if args.quiet:
        verbosity = 0
    else:
        verbosity = args.verbose
    
    # Validate domain
    if not validate_domain(args.target):
        print(f"Error: Invalid domain format: {args.target}")
        sys.exit(1)
    
    # Parse port range if ports module is selected
    ports = None
    if args.ports or args.all:
        ports = parse_port_range(args.ports_range)
    
    # Initialize ReconWizard
    wizard = ReconWizard(args.target, verbosity)
    
    # Check if any modules are selected
    modules_selected = any([args.whois, args.dns, args.subdomains, args.ports, args.banner, args.tech, args.all])
    
    if not modules_selected:
        print("Error: No reconnaissance modules selected. Use --help for usage information.")
        sys.exit(1)
    
    # Run selected modules
    try:
        if args.all:
            wizard.run_all(ports)
        else:
            if args.whois:
                wizard.run_whois()
            if args.dns:
                wizard.run_dns_enum()
            if args.subdomains:
                wizard.run_subdomain_enum()
            if args.ports:
                wizard.run_port_scan(ports)
            if args.banner and wizard.results['ports']:
                wizard.run_banner_grab()
            if args.tech:
                wizard.run_tech_detect()
        
        # Generate reports
        wizard.generate_reports(args.output_dir, args.output)
        
        print(f"\nReconnaissance completed for {args.target}")
        print(f"Reports saved in: {args.output_dir}")
        
    except KeyboardInterrupt:
        print("\n\nScan interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()